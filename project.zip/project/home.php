<?php
//$host="localhost";
//$user="root";
//$password="";
//$db="test";

//mysqli_connect($host,$user,$password);
$con=mysqli_connect('localhost','root','','users');
//mysqli_select_db($db);

if(isset($_POST['email'])){
    $email=$_POST['email'];
    $password=$_POST['pass'];
    
    $sql="select * from regilist where email='".$email."' AND password='".$password."' limit 1 ";
     
    $result=mysqli_query($con,$sql);
    
    if(mysqli_num_rows($result)==1){
        echo "sussessful";
        header('Location: singin.html');
        exit();
    }
    else{
        echo "incorrect";
        exit();
    }
}
?>

<html>
    <head>

        <title>Sign In Page</title>
        <link rel="stylesheet" href="CSS/style.css">
    </head>

	<body>

	    <div class="container">
	        <div class="login-box">
	            <img src="image/user.jpg" class="user" alt="user image">
	            <h2>Sign In here</h2>
	            <form action="#" method="post">
          
                    <label for="email">Email</label>
	                <input id="email" type="text" name="email" placeholder="Enter your email" required>
	                <label for="password">Password</label>
                    <input id="password" type="password" name="pass" placeholder=" Enter your password" required>
	               <input type="submit" id="submit" value="Sign In">
	                
                    <a href="register.html">Create an account</a><br><br>
                    <a href="#">Forgot Password</a>
	            </form>
	        </div>
	    </div>	
	</body>

</html>
