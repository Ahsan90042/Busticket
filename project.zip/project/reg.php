<?php
$con=mysqli_connect('localhost','root','','users');


$firstname=$_POST['fn'];
$lastname=$_POST['ln'];
$email=$_POST['email'];
$password=$_POST['pass'];
$image=$_POST['img'];


$sql="insert into regilist(firstname,lastname,email,password,image) values
 ('$firstname','$lastname','$email','$password','$image')";
mysqli_query($con,$sql);
echo "Successfuly Create Your Account";
?>