<?php
$con=mysqli_connect('localhost','root','','users');
?>
<h1> Customer Information </h1>
<?php
   $sql="select * FROM regilist";
   $res=mysqli_query($con,$sql);
?>
<html>
<body>
   <table border="1">
     <tr>
       <td>First Name</td>
       <td>Last Name</td>
       <td>Email</td>
       <td>password</td>
       <td>image</td>
     </tr>

<?php
      
while($row=mysqli_fetch_assoc($res))
{

?>
<tr>

        
<td bgcolor="red"> <?php echo $row["firstname"]; ?> </td>
<td bgcolor="blue"> <?php echo $row["lastname"]; ?> </td>
<td bgcolor="yellow"> <?php echo $row["email"]; ?> </td>
<td bgcolor="blue"> <?php echo $row["password"]; ?> </td>
<td bgcolor="yellow"> <?php echo $row["image"]; ?> </td>


</tr>
<?php
}
?>

</table>
</body>
</html>