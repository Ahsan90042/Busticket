<?php


$con=mysqli_connect('localhost','root','','users');
?>



<?php

    $sql = "DELETE FROM REGILIST WHERE email='mr@gmail.com'";
	$res = mysqli_query($con,$sql);
	echo "The data has been deleted successfully";
	?>

