<html>
<head>
    
    <title>Search for a user</title>
    
    </head>
    <body>
    <h2>Search for a user below:</h2><br><br>
        <form action="profile.php" method="get">
            <table>
            <tr><td>Enter Your Email:</td><td><input type="text" id="email" name="email"></td></tr>
                <tr><td><input type="submit" id="submit" name="submit" value="View Profile!"></td></tr>

            </table>
        
        
        </form>
    
    </body>
</html>