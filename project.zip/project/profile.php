<html>
    <head>
        
    </head>
    <body>
<?php
//cheakh for a form submission
        
        $con= mysqli_connect('localhost','root','','users') or die ("could not connect to server");
if(isset($_GET['email'])){
    $email = $_GET['email'];
    

    $userquery= "SELECT * FROM regilist WHERE email='$email'";
   $res=mysqli_query($con, $userquery);
    if(mysqli_num_rows($res) != 1){
        die ("that user name could not be found!");
    }
    while($row = mysqli_fetch_array( $res)){
        $firstname=$row['firstname'];
        $lastname=$row['lastname'];
        $email =$row['email'];
        $password =$row['password'];
        $image =$row['image'];
        
    }
?>
        <h1>Your Profile</h1>
        <table>
            <tr><td>Image:</td><td><?php echo  $image; ?></td></tr>
        <tr><td>Firstname:</td><td><?php echo $firstname; ?></td></tr>
        <tr><td>Lastname:</td><td><?php echo $lastname; ?></td></tr>
        <tr><td>Email:</td><td><?php echo  $email; ?></td></tr>
        <tr><td>Password:</td><td><?php echo $password; ?></td></tr>
        

        </table>
       
<!--        <a href="update.php"><input type="submit" id="submit" value="Update Your Profile" style="height: 30px" width="50px"></a> -->
   
        
        
<?php
    
}else die ("You need to specify a username!");
        ?>
        <br><br>
      <h1> Update Your Profile</h1>  
    <br><br>
        
    <?php
         if(isset($_POST['update'])) {
//            $dbhost = 'localhost';
//            $dbuser = 'root';
//            $dbpass = '';
//            $dbname='users';
//            $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
            $conn = mysqli_connect('localhost','root','','users');
//            
//            if(! $conn ) {
//               die('Could not connect: ' . mysqli_error());
//            }
            
//            $email = $_POST['email'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $email = $_POST['email'];
            $password = $_POST['password'];
             $image=$_POST['image'];
             
            $sql = "UPDATE regilist ". "SET firstname = '$firstname', lastname='$lastname', email='$email', password='$password',image='$image' ". 
               "WHERE email = '$email'" ;
           // mysqli_select_db('users');
            $retval = mysqli_query( $conn, $sql );
            
//            if(! $retval ) {
//               die('Could not update data: ' . mysqli_error());
//            }
//            echo "Updated data successfully\n";
            
//            mysqli_close($conn);
         } 
            ?>

               <form method = "post" action = "">
                  <table width = "400" border =" 0" cellspacing = "1" 
                     cellpadding = "2">
                  
                      <tr>
                    <td width = "10">Image: </td>  
                          <td>
                    <input type="file" name="image" value="fileupload" id="fileupload"> <label for="fileupload"></label>
                              
                  </tr>
                     <tr>
                        <td width = "100">Firstname:</td>
                        <td><input name = "firstname" type = "text" 
                           id = "firstname"></td>
                     </tr>
                      
                      <tr>
                        <td width = "100">Lastname:</td>
                        <td><input name = "lastname" type = "text" 
                           id = "lastname"></td>
                     </tr>
                      
                      <tr>
                        <td width = "100">Email:</td>
                        <td><input name = "email" type = "text" 
                           id = "email"></td>
                     </tr>
                      
                      <tr>
                        <td width = "100">Password:</td>
                        <td><input name = "password" type = "text" 
                           id = "assword"></td>
                     </tr>
                      
                     
                      
                     <tr>
                        <td width = "100"> </td>
                        <td> </td>
                     </tr>
                  
                     <tr>
                        <td width = "100"> </td>
                        <td>
                           <input name = "update" type = "submit" 
                              id = "update" value = "Update">
                        </td>
                     </tr>
                  
                  </table>
                   <a href="singin.html">Back</a>
               </form>
      
   </body>
</html>

